-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u1
-- http://www.phpmyadmin.net
--
-- Client :  sqletud.univ-mlv.fr
-- Généré le :  Sam 06 Février 2016 à 01:01
-- Version du serveur :  5.5.40-0+wheezy1-log
-- Version de PHP :  5.6.14-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `jchattou_db`
--

--
-- Contenu de la table `Prescriptions`
--

INSERT INTO `Prescriptions` (`prescription_id`, `libelle_prescription`, `dosage`) VALUES
(1, 'MED_001', NULL),
(2, 'MED_002', NULL),
(3, 'MED_003', NULL),
(4, 'MED_004', NULL),
(5, 'MED_005', NULL),
(6, 'MED_006', NULL),
(7, 'MED_007', NULL),
(8, 'MED_008', NULL),
(9, 'MED_009', NULL),
(10, 'MED_010', NULL),
(11, 'MED_011', NULL),
(12, 'MED_012', NULL),
(13, 'MED_013', NULL),
(14, 'MED_014', NULL),
(15, 'MED_015', NULL),
(16, 'MED_016', NULL),
(17, 'MED_017', NULL),
(18, 'Consultation kinésithérapeutes', NULL),
(19, 'Consultation ophtalmologue', NULL),
(20, 'Consultation ortoptiste', NULL),
(21, 'Bilan sanguin', NULL),
(22, 'Test VIH', NULL),
(23, 'Radio des poumons', NULL),
(24, 'IRM du thorax', NULL),
(25, 'Radio du dos', NULL),
(26, 'IRM de la tête', NULL),
(27, 'Radio du thorax', NULL),
(28, 'IRM pelvienne', NULL),
(29, 'Radio du membre inférieur', NULL),
(30, 'IRM cérébral', NULL),
(31, 'IRM Pulmonaire', NULL),
(32, 'Radio de l''abdomen', NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
