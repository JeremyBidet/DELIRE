-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u1
-- http://www.phpmyadmin.net
--
-- Client :  sqletud.univ-mlv.fr
-- Généré le :  Ven 05 Février 2016 à 20:19
-- Version du serveur :  5.5.40-0+wheezy1-log
-- Version de PHP :  5.6.14-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `jchattou_db`
--

--
-- Contenu de la table `Specialites`
--

INSERT INTO `Specialites` (`specialite_id`, `specialite_libelle`) VALUES
(1, 'Rhumatologue'),
(2, 'Chirurgien Urologue'),
(3, 'Cardiologue'),
(4, 'Neurologue'),
(5, 'Gynécologue -  Obstétricien'),
(7, 'Secrétaire'),
(8, 'Médecin'),
(9, 'Anesthésiste-Réanimateur'),
(10, 'Infirmier'),
(11, 'Pharmacien'),
(12, 'Neuro chirurgien'),
(13, 'Chirurgien'),
(14, 'Ophtalmologue'),
(15, 'Gastro-entérologue'),
(16, 'ORL'),
(17, 'Biologie médicale'),
(18, 'Radiodiagnostic');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
